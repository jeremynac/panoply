# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['toolbox']

package_data = \
{'': ['*']}

install_requires = \
['simple-term-menu>=1.4.1,<2.0.0']

entry_points = \
{'console_scripts': ['toolbox = toolbox:main']}

setup_kwargs = {
    'name': 'toolbox',
    'version': '0.1.4',
    'description': '',
    'long_description': None,
    'author': 'Jeremy Naccache',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
