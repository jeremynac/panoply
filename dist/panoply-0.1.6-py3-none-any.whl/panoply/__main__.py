from panoply import main

main()